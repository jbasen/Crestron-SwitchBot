﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;

namespace SwitchBot_Integration
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class SwitchBot
	{
		#region Declarations
		private static Debug_Options Debug;
		private static string Token;
		#endregion

		//****************************************************************************************
		// 
		//  SwitchBot	-	Default Constructor
		// 
		//****************************************************************************************
		public SwitchBot()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Token, short Debug)
		{
			#region Save Parameters
			SwitchBot.Token = Token;
			#endregion

			Set_Debug_Message_Output(Debug);

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Get_Device_List	-	Gets the list of devices associated with an account
		// 
		//****************************************************************************************
		public void Get_Device_List()
		{
			#region Create url
			//Create url
			string url = "https://api.switch-bot.com/v1.0/devices";
			Debug_Message("Get_Devices_List", "URL: " + url);
			#endregion

			#region Get List of Devices
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpsHeader("Authorization", Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SwitchBot - Get_Devices_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Devices_List", "response.ContentString: " + s);
					//Get devices from returned json
					s = Parse_Data_Substring(s, "", "\"deviceList\":[", "],\"infraredRemoteList\":") + " ";
					Debug_Message("Get_Devices_List", "DeviceList: " + s);
					//initialize values for loop
					int open_curly_brace = s.IndexOf("{", 0);
					int close_curly_brace = s.IndexOf("}", 0);
					//loop until all IDs found
					while ((open_curly_brace != -1) && (close_curly_brace != -1))
					{
						//get string with one device id
						string t = s.Substring(open_curly_brace, close_curly_brace + 1);
						//parse device Info
						string Device_ID = Parse_Data_Substring(t, "", "\"deviceId\":\"", "\"");
						string Device_Name = Parse_Data_Substring(t, "", "\"deviceName\":\"", "\"");
						string Device_Type = Parse_Data_Substring(t, "", "\"deviceType\":\"", "\"");
						Debug_Message("Get_Devices_List", "SwitchBot Device Name = " + Device_Name + ", Device Type = " + Device_Type + ", Device ID = " + Device_ID);
						//check for error
						if (string.IsNullOrEmpty(Device_ID) || string.IsNullOrEmpty(Device_Name) || string.IsNullOrEmpty(Device_Type))
						{
							string err = "SwitchBot - Get_Devices_List - Can't Find Device_ID in json: " + t;
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return;
						}
						else
						{
							//Display info to console
							CrestronConsole.PrintLine("SwitchBot Device Name = " + Device_Name + ", Device Type = " + Device_Type + ", Device ID = " + Device_ID);
						}
						//discard parsed json and get indices to next device info
						s = s.Remove(0, close_curly_brace + 1);
						open_curly_brace = s.IndexOf("{", 0);
						close_curly_brace = s.IndexOf("}", 0);
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "SwitchBot - Get_Devices_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Scene_List	-	Gets the list of scenes associated with an account
		// 
		//****************************************************************************************
		public void Get_Scene_List()
		{
			#region Create url
			//Create url
			string url = "https://api.switch-bot.com/v1.0/scenes";
			Debug_Message("Get_Scene_List", "URL: " + url);
			#endregion

			#region Get List of Scenes
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpsHeader("Authorization", Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SwitchBot - Get_Scene_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Scene_List", "response.ContentString: " + s);
					//Get devices from returned json
					s = Parse_Data_Substring(s, "", "\"body\":[", "]") + " ";
					Debug_Message("Get_Scene_List", "Scene List: " + s);
					//initialize values for loop
					int open_curly_brace = s.IndexOf("{", 0);
					int close_curly_brace = s.IndexOf("}", 0);
					//loop until all IDs found
					while ((open_curly_brace != -1) && (close_curly_brace != -1))
					{
						//get string with one device id
						string t = s.Substring(open_curly_brace, close_curly_brace + 1);
						//parse device Info
						string Scene_ID = Parse_Data_Substring(t, "", "\"sceneId\":\"", "\"");
						string Scene_Name = Parse_Data_Substring(t, "", "\"sceneName\":\"", "\"");
						//check for error
						if (string.IsNullOrEmpty(Scene_ID) || string.IsNullOrEmpty(Scene_Name))
						{
							string err = "SwitchBot - Get_Scene_List - Can't Find Scene_ID in json: " + t;
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return;
						}
						else
						{
							//Display info to console
							CrestronConsole.PrintLine("SwitchBot Scene Name = " + Scene_Name + ", Scene ID = " + Scene_ID);
						}
						//discard parsed json and get indices to next device info
						s = s.Remove(0, close_curly_brace + 1);
						open_curly_brace = s.IndexOf("{", 0);
						close_curly_brace = s.IndexOf("}", 0);
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "SwitchBot - Get_Scene_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}
	
		//****************************************************************************************
		// 
		//  Send_Command	-	Send Command to Device. Valid Commands are "turnOn", "turnOff",
		//						"press" for a SwitchBot, and "turnOn" and "turnOff" for a curtain
		// 
		//****************************************************************************************
		public void Send_Command(string Device_ID, string Command, string Parameter)
		{
			string p;

			#region Create url
			string url = "https://api.switch-bot.com/v1.0/devices/" + Device_ID + "/commands";
			Debug_Message("Send_Command", "URL: " + url);
			#endregion

			#region Create json body
			if (string.IsNullOrEmpty(Parameter) == true)
			{
				p = "default";
			}
			else
			{
				p = Parameter;
			}
			string json = "{\"command\":\"" + Command + "\",\"parameter\":\"" + p + "\",\"commandType\":\"command\"}";
			Debug_Message("Send_Command", "json: " + json);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				httpsClient.Accept = "application/json";
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpsHeader("Authorization", Token));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Send_Command", "Error - response.Code = " + response.Code);
					Debug_Message("Send_Command", "Error - response.ContentString = " + response.ContentString);
				}
				else
				{
					//Success
					Debug_Message("Send_Command", "Success - response.Code = " + response.Code);
					Debug_Message("Send_Command", "Success - response.ContentString = " + response.ContentString);
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("SwitchBot - Send_Command - Error sending command: " + Command);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot - Send_Command - Error sending command: " + Command);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Execute_Scene	-	Send Command to Execute a Scene
		// 
		//****************************************************************************************
		public void Execute_Scene(string Scene_ID)
		{
			#region Create url
			string url = "https://api.switch-bot.com/v1.0/scenes/" + Scene_ID + "/execute";
			Debug_Message("Execute_Scene", "URL: " + url);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				httpsClient.Accept = "application/json";
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpsHeader("Authorization", Token));
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Execute_Scene", "Error - response.Code = " + response.Code);
					Debug_Message("Execute_Scene", "Error - response.ContentString = " + response.ContentString);
				}
				else
				{
					//Success
					Debug_Message("Execute_Scene", "Success - response.Code = " + response.Code);
					Debug_Message("Execute_Scene", "Success - response.ContentString = " + response.ContentString);
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("SwitchBot - Execute_Scene - Error executing scene: " + Scene_ID);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot - Execute_Scene - Error executing scene: " + Scene_ID);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					SwitchBot.Debug = Debug_Options.None;
					break;

				case 1:
					SwitchBot.Debug = Debug_Options.Console;
					break;

				case 2:
					SwitchBot.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					SwitchBot.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("SwitchBot - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("SwitchBot - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
