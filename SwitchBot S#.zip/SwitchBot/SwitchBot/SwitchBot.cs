﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.Cryptography;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace SwitchBot_Integration
{
	#region Enum
	enum Temperature_Format_Options
	{
		Celsius,
		Fahrenheit
	};

	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class SwitchBot
	{
		#region Declarations
		private static Debug_Options Debug;
		private static string Security_Token;
		private static string Secret_Key;
		#endregion

		//****************************************************************************************
		// 
		//  SwitchBot	-	Default Constructor
		// 
		//****************************************************************************************
		public SwitchBot()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Security_Token, string Secret_Key, short Debug)
		{
			#region Save Parameters
			SwitchBot.Security_Token = Security_Token;
			SwitchBot.Secret_Key = Secret_Key;
			#endregion

			Set_Debug_Message_Output(Debug);

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Get_Device_List	-	Gets the list of devices associated with an account
		// 
		//****************************************************************************************
		public void Get_Device_List()
		{
			HttpsClient client = null;
			string time = "";
			string nonce = "";
			string signature = "";

			#region Create url
			//Create url
			string url = "https://api.switch-bot.com/v1.1/devices";
			Debug_Message("Get_Devices_List", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Get List of Devices
			try
			{
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time.ToString()));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SwitchBot - Get_Devices_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Devices_List", "response.ContentString: " + s);
					//Get devices from returned json
					s = Parse_Data_Substring(s, "", "\"body\":", ",\"infraredRemoteList\":") + "}";
					Debug_Message("Get_Devices_List", "DeviceList: " + s);

					Device_List List = Device_List.Parse(s);
					if (List != null)
					{
						//Loop through list
						for (int i = 0; i < List.deviceList.Count; i++)
						{
							CrestronConsole.PrintLine("SwitchBot Device Name = " + List.deviceList[i].deviceName + ", Device Type = " + List.deviceList[i].deviceType + ", Device ID = " + List.deviceList[i].deviceID);
						}
					}
					else
					{
						string err = "SwitchBot - Get_Devices_List - No devices found in json: " + s;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "SwitchBot - Get_Devices_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Scene_List	-	Gets the list of scenes associated with an account
		// 
		//****************************************************************************************
		public void Get_Scene_List()
		{
			HttpsClient client = null;
			string time = "";
			string nonce = "";
			string signature = "";

			#region Create url
			//Create url
			string url = "https://api.switch-bot.com/v1.1/scenes";
			Debug_Message("Get_Scene_List", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Get List of Scenes
			try
			{
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time.ToString()));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SwitchBot - Get_Scene_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Scene_List", "response.ContentString: " + s);
					//Get devices from returned json
					s = Parse_Data_Substring(s, "", "\"body\":[", "]") + " ";
					Debug_Message("Get_Scene_List", "Scene List: " + s);
					//initialize values for loop
					int open_curly_brace = s.IndexOf("{", 0);
					int close_curly_brace = s.IndexOf("}", 0);
					//loop until all IDs found
					while ((open_curly_brace != -1) && (close_curly_brace != -1))
					{
						//get string with one device id
						string t = s.Substring(open_curly_brace, close_curly_brace + 1);
						//parse device Info
						string Scene_ID = Parse_Data_Substring(t, "", "\"sceneId\":\"", "\"");
						string Scene_Name = Parse_Data_Substring(t, "", "\"sceneName\":\"", "\"");
						//check for error
						if (string.IsNullOrEmpty(Scene_ID) || string.IsNullOrEmpty(Scene_Name))
						{
							string err = "SwitchBot - Get_Scene_List - Can't Find Scene_ID in json: " + t;
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return;
						}
						else
						{
							//Display info to console
							CrestronConsole.PrintLine("SwitchBot Scene Name = " + Scene_Name + ", Scene ID = " + Scene_ID);
						}
						//discard parsed json and get indices to next device info
						s = s.Remove(0, close_curly_brace + 1);
						open_curly_brace = s.IndexOf("{", 0);
						close_curly_brace = s.IndexOf("}", 0);
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "SwitchBot - Get_Scene_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}
	
		//****************************************************************************************
		// 
		//  Send_Command	-	Send Command to Device. Valid Commands are "turnOn", "turnOff",
		//						"press" for a SwitchBot, "turnOn" and "turnOff" for a curtain,
		//						and "lock" and "unlock" for a lock
		// 
		//****************************************************************************************
		public void Send_Command(string Device_ID, string Command, string Parameter)
		{
			HttpsClient client = null;
			string p;
			string time = "";
			string nonce = "";
			string signature = "";

			#region Create url
			string url = "https://api.switch-bot.com/v1.1/devices/" + Device_ID + "/commands";
			Debug_Message("Send_Command", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Create json body
			if (string.IsNullOrEmpty(Parameter) == true)
			{
				p = "\"default\"";
			}
			else
			{
				p = Parameter;
			}
			string json = "{\"command\":\"" + Command + "\",\"parameter\":" + p + ",\"commandType\":\"command\"}";
			Debug_Message("Send_Command", "json: " + json);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				httpsClient.Accept = "application/json";
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Send_Command", "Error - response.Code = " + response.Code);
					Debug_Message("Send_Command", "Error - response.ContentString = " + response.ContentString);
				}
				else
				{
					//Success
					Debug_Message("Send_Command", "Success - response.Code = " + response.Code);
					Debug_Message("Send_Command", "Success - response.ContentString = " + response.ContentString);
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("SwitchBot - Send_Command - Error sending command: " + Command);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot - Send_Command - Error sending command: " + Command);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Lock_State	-	Returns lock and door state
		// 
		//****************************************************************************************
		public string Get_Lock_State(string Device_ID)
		{
			HttpsClient client = null;
			string time = "";
			string nonce = "";
			string signature = "";

			#region Create url
			string url = "https://api.switch-bot.com/v1.1/devices/" + Device_ID + "/status";
			Debug_Message("Get_Lock_State", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time.ToString()));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Get_Lock_State", "Error - response.Code = " + response.Code);
					Debug_Message("Get_Lock_State", "Error - response.ContentString = " + response.ContentString);
					return null;
				}
				else
				{
					Debug_Message("Get_Lock_State", "Success - response.ContentString = " + response.ContentString);
					string lock_state = Parse_Data_Substring(response.ContentString, "", "\"lockState\":\"", "\"");
					Debug_Message("Get_Lock_State", "Lock State = " + lock_state);
					string door_state = Parse_Data_Substring(response.ContentString, "", "\"doorState\":\"", "\"");
					Debug_Message("Get_Lock_State", "Door State = " + door_state);
					return lock_state + "," + door_state;
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "SwitchBot - Get_Lock_State - Error Retreiving Lock Status" + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Meter_State	-	Returns temperature and Humidity
		// 
		//****************************************************************************************
		public short Get_Meter_State(string Device_ID, short Temperature_Format_Selection, ref short Temperature_Param, ref ushort Humidity_Param, ref ushort CO2_Param, ref ushort Battery_Param)
		{
			HttpsClient client = null;
			string time = "";
			string nonce = "";
			string signature = "";
			Temperature_Format_Options Temperature_Format;
			double Temperature;

			#region Temperature Format
			switch (Temperature_Format_Selection)
			{
				case 0:
					Temperature_Format = Temperature_Format_Options.Fahrenheit;
					break;

				case 1:
					Temperature_Format = Temperature_Format_Options.Celsius;
					break;

				default:
					Debug_Message("Get_Meter_State", "Error - Invalid Temperature_Format_Selection = " + Temperature_Format_Selection);
					Temperature_Format = Temperature_Format_Options.Fahrenheit;
					break;
			}
			#endregion

			#region Create url
			string url = "https://api.switch-bot.com/v1.1/devices/" + Device_ID + "/status";
			Debug_Message("Get_Meter_State", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time.ToString()));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Get_Meter_State", "Error - response.Code = " + response.Code);
					Debug_Message("Get_Meter_State", "Error - response.ContentString = " + response.ContentString);
					return 0;
				}
				else
				{
					Debug_Message("Get_Meter_State", "Success - response.ContentString = " + response.ContentString);
					Meter_Info info = JsonConvert.DeserializeObject<Meter_Info>(response.ContentString);
					if (info != null)
					{
						Debug_Message("Get_Meter_State", "Temperature = " + info.body.temperature + ", Humidity = " + info.body.humidity + ", CO2 = " + info.body.CO2 + ", Battery = " + info.body.battery);
						Temperature = info.body.temperature;
						if (Temperature_Format == Temperature_Format_Options.Fahrenheit)
						{
							Temperature = Celsius_To_Fahrenheit(Temperature);
						}
						Temperature = Temperature * 10;
						Temperature = Math.Round(Temperature, 0);
						Debug_Message("Get_Meter_State", "Temperature = " + Temperature + ", Humidity = " + info.body.humidity);
						Temperature_Param = Convert.ToInt16(Temperature);
						Humidity_Param = Convert.ToUInt16(info.body.humidity);
						CO2_Param = Convert.ToUInt16(info.body.CO2);
						Battery_Param = Convert.ToUInt16(info.body.battery);
						return 1;
					}
					else
					{
						Debug_Message("Get_Meter_State", "JSON COnvert Returned null");
						return 0;
					}
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "SwitchBot - Get_Meter_State - Error Retreiving Meter Status" + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Vacuum_State	-	Returns vacuum state
		// 
		//****************************************************************************************
		public string Get_Vacuum_State(string Device_ID)
		{
			HttpsClient client = null;
			string time = "";
			string nonce = "";
			string signature = "";

			#region Create url
			string url = "https://api.switch-bot.com/v1.1/devices/" + Device_ID + "/status";
			Debug_Message("Get_Vacuum_State", "URL: " + url);
			#endregion

			#region v1.1 Security
			Create_Security_Signature(ref time, ref nonce, ref signature);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.AddHeader(new HttpsHeader("authorization", Security_Token));
				request.Header.AddHeader(new HttpsHeader("sign", signature));
				request.Header.AddHeader(new HttpsHeader("nonce", nonce));
				request.Header.AddHeader(new HttpsHeader("t", time.ToString()));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Get_Vacuum_State", "Error - response.Code = " + response.Code);
					Debug_Message("Get_Vacuum_State", "Error - response.ContentString = " + response.ContentString);
					return null;
				}
				else
				{
					Debug_Message("Get_Vacuum_State", "Success - response.ContentString = " + response.ContentString);
					Vacuum_Info info = JsonConvert.DeserializeObject<Vacuum_Info>(response.ContentString);
					if (info != null)
					{
						Debug_Message("Get_Vacuum_State", "Working Status = " + info.body.workingStatus + ", Online Status = " + info.body.onlineStatus);
						return info.body.workingStatus + "," + info.body.onlineStatus;
					}
					else
					{
						Debug_Message("Get_Vacuum_State", "JSON COnvert Returned null");
						return null;
					}
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "SwitchBot - Get_Vacuum_State - Error Retreiving Vacuum Status" + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Execute_Scene	-	Send Command to Execute a Scene
		// 
		//****************************************************************************************
		public void Execute_Scene(string Scene_ID)
		{
			HttpsClient client = null;

			#region Create url
			string url = "https://api.switch-bot.com/v1.0/scenes/" + Scene_ID + "/execute";
			Debug_Message("Execute_Scene", "URL: " + url);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				httpsClient.Accept = "application/json";
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpsHeader("Authorization", Security_Token));
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Execute_Scene", "Error - response.Code = " + response.Code);
					Debug_Message("Execute_Scene", "Error - response.ContentString = " + response.ContentString);
				}
				else
				{
					//Success
					Debug_Message("Execute_Scene", "Success - response.Code = " + response.Code);
					Debug_Message("Execute_Scene", "Success - response.ContentString = " + response.ContentString);
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("SwitchBot - Execute_Scene - Error executing scene: " + Scene_ID);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot - Execute_Scene - Error executing scene: " + Scene_ID);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Celsius_To_Fahrenheit	-	Convert Temperaute in Celsius to Fahrenheit
		// 
		//****************************************************************************************
		private double Celsius_To_Fahrenheit(double Celsius)
		{
			return (Celsius * 1.8) + 32;
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("SwitchBot-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("SwitchBot-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					SwitchBot.Debug = Debug_Options.None;
					break;

				case 1:
					SwitchBot.Debug = Debug_Options.Console;
					break;

				case 2:
					SwitchBot.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					SwitchBot.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("SwitchBot - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("SwitchBot - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

		//****************************************************************************************
		// 
		//  Create_Security_Signature	-	Create security signature for v1.1 security
		// 
		//****************************************************************************************
		private void Create_Security_Signature(ref string time_param, ref string nonce_param, ref string signature_param)
		{
			DateTime current = DateTime.UtcNow;
			var dt1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			var time = current.ToUniversalTime().Subtract(dt1970).TotalMilliseconds;

			Guid g = Guid.NewGuid();
			string nonce = g.ToString();
			string data = Security_Token + time.ToString() + nonce;

			Encoding utf8 = Encoding.UTF8;
			HMACSHA256 hmac = new HMACSHA256(utf8.GetBytes(Secret_Key));
			string signature = Convert.ToBase64String(hmac.ComputeHash(utf8.GetBytes(data)));

			Debug_Message("Security_Test", "time = " + time);
			Debug_Message("Security_Test", "nonce = " + nonce);
			Debug_Message("Security_Test", "signature = " + signature);

			time_param = time.ToString();
			nonce_param = nonce;
			signature_param = signature;
		}

		public class Device_List
		{
			#region Declarations
			public List<Devicet_Info> deviceList { get; set; }
			#endregion Declarations

			//****************************************************************************************
			// 
			//  Parse	-   Parse input status from gen 1 devices
			// 
			//****************************************************************************************
			public static Device_List Parse(string JSON)
			{
				try
				{
					return JsonConvert.DeserializeObject<Device_List>(JSON);
				}
				catch (Exception e)
				{
					string err = "Error Parsing JSON: " + e;
					CrestronConsole.PrintLine("Device_List - Parse", err);
					Crestron.SimplSharp.ErrorLog.Error("Device_List - Parse - " + err + "\n");
					return null;
				}
			}
		}

		public class Devicet_Info
		{
			#region Declarations
			public string deviceID { get; set; }
			public string deviceName { get; set; }
			public string deviceType { get; set; }
			#endregion
		}

		public class Meter_Details
		{
			public string deviceId { get; set; }
			public string deviceType { get; set; }
			public string hubDeviceId { get; set; }
			public int humidity { get; set; }
			public double temperature { get; set; }
			public string version { get; set; }
			public int battery { get; set; }
			public int CO2 { get; set; }
		}

		public class Meter_Info
		{
			public int statusCode { get; set; }
			public Meter_Details body { get; set; }
			public string message { get; set; }
		}

		public class Vacuum_Details
		{
			public string deviceId { get; set; }
			public string deviceName { get; set; }
			public string deviceType { get; set; }
			public string hubDeviceId { get; set; }
			public string workingStatus { get; set; }
			public string onlineStatus { get; set; }
			public int battery { get; set; }
		}

		public class Vacuum_Info
		{
			public int statusCode { get; set; }
			public Vacuum_Details body { get; set; }
			public string message { get; set; }
		}

	}
}
