﻿using System.Reflection;

[assembly: AssemblyTitle("SwitchBot")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("SwitchBot")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2021")]
[assembly: AssemblyVersion("1.0.0.*")]

